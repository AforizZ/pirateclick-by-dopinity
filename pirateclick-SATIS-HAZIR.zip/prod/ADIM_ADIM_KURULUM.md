# 🏴‍☠️ PirateClick by dopinity
# SATIŞ HAZIR SİSTEM — ADIM ADIM KURULUM REHBERİ

---

## 📌 GENEL BAKIŞ

Bu sistemde 2 ayrı parça var:

| Parça | Ne yapar | Nerede çalışır |
|-------|----------|----------------|
| **Backend (API)** | Lisans kontrolü, WhatsApp botu, dispatch sistemi | Bulut sunucu (Railway) |
| **Electron (EXE)** | Müşterinin bilgisayarında çalışan masaüstü uygulama | Müşteri bilgisayarı |

**Çalışma mantığı:**
```
Müşteri EXE açar → Backend API'ye bağlanır → Lisans kontrol eder → İzin varsa giriş
```

---

## 🖥️ BİLGİSAYAR GEREKSİNİMLERİ

- Windows 10/11 64-bit
- Node.js v18+ (https://nodejs.org → LTS indirin)
- Git (https://git-scm.com)
- İnternet bağlantısı

---

# BÖLÜM 1: BULUT ALTYAPI KURULUMU

---

## ☁️ ADIM 1 — MongoDB Atlas (Ücretsiz Veritabanı)

1. https://mongodb.com/atlas adresine gidin
2. "Try Free" → Google ile kayıt olun
3. **"Create a FREE cluster"** seçin → M0 Free Tier
4. Cloud provider: **AWS**, Region: **Frankfurt (eu-central-1)**
5. Cluster Name: `pirateclick` → **Create**

### Kullanıcı Oluşturma
- Sol menü → **Database Access** → **Add New Database User**
- Username: `pirateclick_user`
- Password: Güçlü bir şifre yazın → **kopyalayın**
- Role: **Atlas Admin** → **Add User**

### IP Erişimi Açma
- Sol menü → **Network Access** → **Add IP Address**
- **Allow Access From Anywhere** (0.0.0.0/0) → **Confirm**

### Bağlantı String'i Alma
- **Database** → **Connect** → **Drivers**
- Driver: Node.js, Version: 5.5+
- **Standard Connection String** (SRV değil, standart olanı seçin!)
- Şu formatta bir şey göreceksiniz:

```
mongodb://pirateclick_user:SIFRENIZ@ac-xxx.mongodb.net:27017,ac-xxx.mongodb.net:27017/pirateclick?ssl=true&replicaSet=atlas-xxx&authSource=admin
```

📌 **Bu string'i not alın**

---

## ⚡ ADIM 2 — Upstash Redis (Ücretsiz Queue Sistemi)

1. https://upstash.com adresine gidin → Google ile kayıt
2. **Create Database** → Type: **Redis**
3. Name: `pirateclick`, Region: **EU-West-1**
4. **Create** → Veritabanı oluşturulur

### Bağlantı Bilgileri
- Database sayfasına gidin → **Details** sekmesi
- **"Redis URL"** satırını bulun:

```
rediss://default:SIFRE@sunny-ocelot-xxxxx.upstash.io:6379
```

📌 **Bu URL'yi not alın**

---

## 🚀 ADIM 3 — Railway Deploy (Backend Sunucu)

1. https://railway.app adresine gidin → GitHub ile kayıt
2. **New Project** → **Deploy from GitHub repo**
3. Eğer repo yoksa: **Empty Project** → **Add Service** → **GitHub Repo**

### Dosyaları Yüklemek İçin
Önce GitHub'a push edin:

```bash
# Bilgisayarınızda backend klasöründe
cd pirateclick/backend

git init
git add .
git commit -m "PirateClick backend"

# GitHub'da yeni repo oluşturun: github.com/new
# Sonra:
git remote add origin https://github.com/KULLANICI/pirateclick-backend.git
git push -u origin main
```

### Railway'de Ortam Değişkenleri
Railway → Service → **Variables** sekmesi → Her birini ekleyin:

```
PORT                     = 3001
NODE_ENV                 = production
LOG_LEVEL                = info

MONGO_URI                = (mongodb:// ile başlayan string)
REDIS_URL                = (rediss:// ile başlayan URL)

JWT_SECRET               = (generateSecrets çıktısından)
ADMIN_API_KEY            = (generateSecrets çıktısından)
ADMIN_WA_NUMBER          = 905XXXXXXXXX

WA_SESSION_PATH          = ./sessions
NLP_CONFIDENCE_THRESHOLD = 0.65
DRIVER_TTL_SECONDS       = 600
CLAIM_DELAY_MIN_MS       = 100
CLAIM_DELAY_MAX_MS       = 2000
DRIVER_RESPONSE_TIMEOUT_MS = 60000
MAX_DRIVER_RETRIES       = 3
METRICS_FLUSH_INTERVAL_MS = 30000
LEARNING_CYCLE_INTERVAL_MS = 1800000
```

### Secret Üretme (JWT + Admin Key)
Bilgisayarınızda backend klasöründe:

```bash
node scripts/generateSecrets.js
```

Çıkan değerleri Railway Variables'a yapıştırın.

### Deploy
Railway → Service → **Deploy** butonuna basın.
Logları izleyin, şunu görmelisiniz:
```
🚀 PirateClick backend started (port 3001)
```

### URL Alma
Railway → Service → **Settings** → **Domains** → **Generate Domain**
Size şuna benzer bir URL verir:
```
https://pirateclick-backend-xxxx.railway.app
```
📌 **Bu URL'yi not alın — Electron'a girecek**

---

## 📱 ADIM 4 — WhatsApp Bağlama

Backend deploy olduktan sonra WhatsApp'ı bağlamanız gerekiyor.

### QR Kodu Görme (Railway Logs)
Railway → Service → **Logs** sekmesini açın.
Terminal çıktısında şunu göreceksiniz:

```
╔══════════════════════════════════════╗
║  📲  WHATSAPP — SCAN QR TO LOGIN    ║
╠══════════════════════════════════════╣
  ██████████████████
  █ ▄▄▄▄▄ █▀▀▀▀▀█ █
  ...
╚══════════════════════════════════════╝
```

**Telefonda:**
1. WhatsApp → Ayarlar → Bağlı Cihazlar
2. Cihaz Bağla → QR'ı taratın
3. `✅ WhatsApp connected successfully!` görünmeli

> 📌 Not: Railway ücretsiz planında uygulama uyku moduna geçebilir. Sürekli aktif olması için Hobby plan ($5/ay) önerilir.

---

# BÖLÜM 2: EXE OLUŞTURMA

---

## 💻 ADIM 5 — Electron'u Hazırlama

Bilgisayarınızda `pirateclick/electron` klasörüne gidin:

```bash
cd pirateclick/electron
```

### API URL'ini Ayarlama (ÇOK ÖNEMLİ)

`src/main.js` dosyasını açın, **7. satırı** bulun:

```js
const BACKEND_URL = process.env.API_URL || 'https://api.pirateclick.com';
```

Bunu Railway URL'iniz ile değiştirin:

```js
const BACKEND_URL = process.env.API_URL || 'https://pirateclick-backend-xxxx.railway.app';
```

Dosyayı kaydedin.

### Icon Ekleme (Satışa Hazır Görünüm)

`build/` klasörüne şu dosyaları ekleyin:

| Dosya | Format | Boyut |
|-------|--------|-------|
| `icon.ico` | Windows icon | 256x256 px |
| `icon.png` | Genel icon | 512x512 px |

**Ücretsiz icon oluşturma:**
- https://www.favicon.io → Text → Logo yaratın
- https://convertio.co/png-ico → PNG'den ICO'ya çevirin

### Paketleri Yükleme

```bash
npm install
```

---

## 🏗️ ADIM 6 — EXE Build

```bash
npm run build:win
```

Bu işlem 5-10 dakika sürebilir. Bitince:

```
dist/PirateClick-Setup-1.0.0.exe
```

Bu EXE artık müşterinize verebileceğiniz kurulum dosyasıdır.

---

# BÖLÜM 3: SATIŞ SÜRECİ

---

## 💰 ADIM 7 — Müşteri Aktivasyon Akışı

### Müşteri Ne Yapar:
1. EXE'yi indirir ve kurar
2. Uygulamayı açar → Login ekranı gelir
3. **Kayıt Ol** sekmesine geçer
4. Ad, telefon, e-posta, şifre doldurur
5. **Hesap Oluştur** der
6. Ekranda şu görünür: "Hesabınız oluşturuldu! Admin onayından sonra giriş yapabilirsiniz."

### Siz Ne Yaparsınız:
WhatsApp'ınıza şu mesaj gelir:
```
🆕 New PirateClick Registration

👤 Name:  Müşteri Adı
📞 Phone: 905XXXXXXXX
📧 Email: musteri@mail.com

⏳ Status: Pending Approval
```

Ardından **curl** veya **Postman** ile:

**1. Kullanıcı ID'sini öğrenin:**
```bash
curl https://RAILWAY_URL/api/admin/users \
  -H "X-Admin-Key: ADMIN_API_KEY"
```

**2. Onaylayın:**
```bash
curl -X POST https://RAILWAY_URL/api/admin/users/USER_ID/approve \
  -H "X-Admin-Key: ADMIN_API_KEY"
```

**3. Lisans Verin:**
```bash
curl -X POST https://RAILWAY_URL/api/admin/licenses/assign \
  -H "X-Admin-Key: ADMIN_API_KEY" \
  -H "Content-Type: application/json" \
  -d "{\"user_id\":\"USER_ID\",\"plan\":\"pro\",\"duration_days\":30}"
```

Müşteriye mesaj gönderin: "Hesabınız aktif edildi, giriş yapabilirsiniz."

---

## 🔑 ADIM 8 — Admin API Referans

Tüm isteklerde header: `X-Admin-Key: ADMIN_API_KEY`

| İşlem | Komut |
|-------|-------|
| Tüm kullanıcıları listele | `GET /api/admin/users` |
| Kullanıcı detayı | `GET /api/admin/users/:id` |
| Kullanıcı onayla | `POST /api/admin/users/:id/approve` |
| Kullanıcı yasakla | `POST /api/admin/users/:id/ban` |
| Cihaz bağını sıfırla | `POST /api/admin/users/:id/reset-device` |
| Lisans ver | `POST /api/admin/licenses/assign` |
| Bitiş tarihi güncelle | `PATCH /api/admin/licenses/:id/expiry` |
| Lisansı iptal et | `DELETE /api/admin/licenses/:id` |

**Lisans Assign Body:**
```json
{
  "user_id": "...",
  "plan": "basic | pro | premium",
  "duration_days": 30
}
```

---

## 📦 ADIM 9 — Plan Detayları

| | BASIC | PRO | PREMIUM |
|--|-------|-----|---------|
| Max Sürücü | 5 | 20 | Sınırsız |
| Mesaj/Dakika | 20 | 60 | 300 |
| Adaptive Learning | ❌ | ✅ | ✅ |
| Analitik | ❌ | ✅ | ✅ |
| Öncelikli Dispatch | ❌ | ❌ | ✅ |
| Multi-Grup | ❌ | ✅ | ✅ |

---

# BÖLÜM 4: SORUN GİDERME

---

## ❓ Sık Karşılaşılan Durumlar

### "Redis ECONNRESET" hatası
- `.env`'de `REDIS_URL` tam olarak `rediss://` ile başlamalı
- Upstash panonuzdan URL'yi yeniden kopyalayın

### "MongoDB auth failed"
- Atlas → Database Access → şifreyi sıfırlayın
- Yeni şifreyi `MONGO_URI`'ye yazın

### "QR kodu göremiyorum" (Railway)
- Railway → Logs → Son log'larda QR ASCII göreceksiniz
- Eğer log sona kaymışsa: servisi restart edin

### "allowed: false" hatası
- Kullanıcı onaylanmamış → approve edin
- Veya lisans atanmamış → assign edin

### "DEVICE_MISMATCH" hatası
- Müşteri farklı bilgisayardan giriş yapmaya çalışıyor
- Çözüm: `POST /api/admin/users/:id/reset-device`

### EXE build hatası
- `npm install` çalıştırdınız mı?
- `build/icon.ico` dosyası var mı?
- Node.js v18+ yüklü mü?

---

## 🔒 Güvenlik Özeti

| Özellik | Durum |
|---------|-------|
| Şifre hashleme | bcrypt 12 round ✅ |
| JWT | HS256, 7 gün, token_version ✅ |
| Device Lock | SHA-256 hardware fingerprint ✅ |
| Token Storage | OS Keychain (keytar) ✅ |
| Rate Limiting | 10 istek/15dk/IP ✅ |
| Admin API | API Key korumalı ✅ |

---

## 📞 Destek

Sorun yaşarsanız hata mesajını kopyalayıp destek kanalına gönderin.

**Sistem:** PirateClick v1.0 by dopinity
