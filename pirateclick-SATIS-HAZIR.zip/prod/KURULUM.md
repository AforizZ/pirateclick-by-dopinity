# 🏴‍☠️ PirateClick by dopinity — Kurulum Rehberi

## ⚡ Hızlı Durum Özeti

Sisteminizin mevcut durumu:
- ✅ Backend API çalışıyor
- ✅ MongoDB bağlanıyor  
- ✅ Redis bağlanıyor (ECONNRESET hatası giderildi)
- ✅ WhatsApp QR artık terminalde görünüyor
- ✅ License sistemi aktif
- ✅ SaaS modülü çalışıyor

---

## 📦 1. Kurulum (İlk Kez)

```bash
cd pirateclick/backend
npm install
```

---

## 🔐 2. Secret Üretme

```bash
node scripts/generateSecrets.js
```

Çıktıyı kopyalayın.

---

## ⚙️ 3. .env Ayarlama

```bash
cp .env.example .env
```

`.env` içini doldurun:

```env
# MongoDB (Atlas → Connect → Drivers → Standard connection string)
MONGO_URI=mongodb://USER:SIFRE@ac-xxx.mongodb.net:27017/pirateclick?ssl=true&replicaSet=...&authSource=admin

# Redis (Upstash → Database → Details → Redis URL)
REDIS_URL=rediss://default:SIFRE@hostname.upstash.io:6379

# Üretilen secret'lar
JWT_SECRET=...
ADMIN_API_KEY=...

# WhatsApp admin bildirimi (+ işareti olmadan, örnek: 905321234567)
ADMIN_WA_NUMBER=905XXXXXXXXX
```

---

## 🚀 4. Backend Başlatma

```bash
npm run dev
```

**Başarılı çıktı şöyle görünmeli:**
```
[LicenseModule] ✅ Routes mounted
Redis [main] connected
Redis [main] ready
MongoDB connected
NLP worker started
Dispatch worker started
🚀 PirateClick backend started (port 3001)

╔══════════════════════════════════════╗
║  📲  WHATSAPP — SCAN QR TO LOGIN    ║
╠══════════════════════════════════════╣
  ██████████████████
  █ ▄▄▄▄▄ █▀▀▀▀▀█ █
  ...
╚══════════════════════════════════════╝
```

---

## 📲 5. WhatsApp Bağlama

1. Telefonunuzda WhatsApp açın
2. **Ayarlar → Bağlı Cihazlar** gidin
3. **Cihaz bağla** seçin
4. Terminaldeki QR kodu taratın
5. `✅ WhatsApp connected successfully!` mesajını bekleyin

---

## 🧪 6. API Test (Sırayla Çalıştırın)

### Kullanıcı Kayıt

```bash
curl -X POST http://localhost:3001/api/auth/register ^
  -H "Content-Type: application/json" ^
  -d "{\"name\":\"Test Kullanici\",\"phone\":\"905321234567\",\"email\":\"test@test.com\",\"password\":\"12345678\"}"
```

**Beklenen:** `"message": "Registration successful. Awaiting admin approval."`
Admin WhatsApp'ınıza bildirim gelir.

---

### Admin Onay

`USER_ID` yerine register'dan gelen `_id` değerini yazın:

```bash
curl -X POST http://localhost:3001/api/admin/users/USER_ID/approve ^
  -H "X-Admin-Key: ADMIN_API_KEY_DEGERINIZ"
```

---

### Lisans Ver

```bash
curl -X POST http://localhost:3001/api/admin/licenses/assign ^
  -H "X-Admin-Key: ADMIN_API_KEY_DEGERINIZ" ^
  -H "Content-Type: application/json" ^
  -d "{\"user_id\":\"USER_ID\",\"plan\":\"pro\",\"duration_days\":30}"
```

**Planlar:** `basic` | `pro` | `premium`

---

### Giriş Yap

```bash
curl -X POST http://localhost:3001/api/auth/login ^
  -H "Content-Type: application/json" ^
  -d "{\"email\":\"test@test.com\",\"password\":\"12345678\",\"device_id\":\"test-device\"}"
```

**Beklenen:** `"token": "eyJ..."` — Bu JWT token'ı kopyalayın.

---

### Lisans Kontrol

```bash
curl http://localhost:3001/api/license/check ^
  -H "Authorization: Bearer JWT_TOKEN_BURAYA" ^
  -H "X-Device-Id: test-device"
```

**Beklenen:** `"allowed": true` 🎉

---

## 🖥️ 7. Electron Kurulum

```bash
cd ../electron
npm install
```

`main.js` içinde API URL'i ayarlayın:

```js
const BACKEND_URL = 'http://localhost:3001'; // geliştirme
// const BACKEND_URL = 'https://api.sizinserver.com'; // production
```

Çalıştırın:

```bash
npm run start:dev
```

Login ekranı açılır → kayıt olun → admin onaylayın → giriş yapın → dashboard açılır.

---

## 🏗️ 8. EXE Build

```bash
cd electron
npm run build:win
```

Çıktı: `electron/dist/PirateClick-Setup-1.0.0.exe`

---

## 🚀 9. Production Deploy

Backend için önerilen: **Railway** veya **Render**

1. GitHub'a push edin
2. Railway/Render → "New Service" → GitHub repo seçin
3. Environment variables ayarlayın (`.env` içindekileri)
4. Deploy edin → URL alın
5. `electron/src/main.js` içinde:
   ```js
   const BACKEND_URL = 'https://SIZIN-URL.railway.app';
   ```
6. EXE build edin: `npm run build:win`

---

## 🔒 Güvenlik Notları

| Özellik | Durum |
|---------|-------|
| Şifre | bcrypt 12 round |
| JWT | HS256, 7 gün, token_version |
| Token Depolama | OS Keychain (keytar) + AES-256-GCM fallback |
| Device Lock | SHA-256 hardware fingerprint |
| Admin API | REST-only, API key korumalı |
| Rate Limit | 10 istek / 15 dk / IP |

---

## ❓ Sık Karşılaşılan Sorunlar

| Hata | Çözüm |
|------|-------|
| `MongoDB auth failed` | Atlas'ta kullanıcı şifresini kontrol edin |
| `Redis ECONNRESET` | `.env`'de `REDIS_URL` formatı `rediss://` ile başlamalı |
| `QR görünmüyor` | `npm install` çalıştırdınız mı? `qrcode-terminal` kurulu olmalı |
| `allowed: false` | Kullanıcı approve edilmeli + lisans atanmalı |
| `DEVICE_MISMATCH` | Admin panelden: `POST /api/admin/users/ID/reset-device` |

---

## 📋 Tüm Admin API Endpointleri

Header: `X-Admin-Key: ADMIN_API_KEY`

```
GET    /api/admin/users                    → Tüm kullanıcılar
GET    /api/admin/users/:id                → Kullanıcı detayı
POST   /api/admin/users/:id/approve        → Kullanıcı onayla
POST   /api/admin/users/:id/ban            → Kullanıcı yasakla
POST   /api/admin/users/:id/reset-device   → Device binding sıfırla

GET    /api/admin/licenses                 → Tüm lisanslar
POST   /api/admin/licenses/assign          → Lisans ata
PATCH  /api/admin/licenses/:id/expiry      → Bitiş tarihi güncelle
DELETE /api/admin/licenses/:id             → Lisansı deaktive et
```

---

## 💰 Plan Karşılaştırması

| Özellik | BASIC | PRO | PREMIUM |
|---------|-------|-----|---------|
| Max sürücü | 5 | 20 | ∞ |
| Max mesaj/dk | 20 | 60 | 300 |
| Öğrenme | ❌ | ✅ | ✅ |
| Analitik | ❌ | ✅ | ✅ |
| Öncelikli dispatch | ❌ | ❌ | ✅ |
| Multi-grup | ❌ | ✅ | ✅ |
