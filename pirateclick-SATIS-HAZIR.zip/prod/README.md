# 🏴‍☠️ PirateClick by dopinity
## WhatsApp AI Dispatch → Commercial SaaS Desktop Product

---

## 📐 Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│  CUSTOMER MACHINE                                               │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  Electron EXE (.exe)                                    │   │
│  │  ┌──────────┐    ┌────────────────────────────────┐    │   │
│  │  │ Auth UI  │    │  Dashboard (existing untouched) │    │   │
│  │  │ Login    │    │  Drivers / Jobs / QR / Settings │    │   │
│  │  │ Register │    └────────────────────────────────┘    │   │
│  │  └────┬─────┘              ↕ WebSocket                  │   │
│  │       │               Local Backend (bundled)           │   │
│  └───────┼───────────────────────────────────────────────────┘   │
│          │ HTTPS                                               │
└──────────┼──────────────────────────────────────────────────────┘
           │
           ▼
┌─────────────────────────────────────────────────────────────────┐
│  CLOUD SERVER                                                   │
│  Node.js API (Express)                                          │
│  ┌────────────────┐  ┌──────────────────┐  ┌───────────────┐  │
│  │ /api/auth/*    │  │ /api/license/*   │  │ /api/admin/*  │  │
│  │ register       │  │ check (startup)  │  │ approve user  │  │
│  │ login          │  │ my               │  │ assign plan   │  │
│  └────────────────┘  └──────────────────┘  └───────────────┘  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  EXISTING DISPATCH SYSTEM (UNTOUCHED)                   │   │
│  │  /api/status  /api/qr  /api/jobs  /api/drivers  etc.    │   │
│  └─────────────────────────────────────────────────────────┘   │
│              ↓                ↓                                 │
│         MongoDB           Redis                                 │
│    (users, licenses,   (job queue,                              │
│     dispatch data)      driver state)                           │
└─────────────────────────────────────────────────────────────────┘
```

### User Flow
```
User downloads EXE
      ↓
Opens app → Auth screen
      ↓
Registers → POST /api/auth/register
      ↓
status = "pending" → Admin gets WhatsApp notification
      ↓
Admin: POST /api/admin/users/:id/approve
Admin: POST /api/admin/licenses/assign
      ↓
User logs in → POST /api/auth/login
      ↓
Electron → GET /api/license/check (with device_id header)
      ↓
If allowed=true → Dashboard opens
If allowed=false → Block screen shown
```

---

## 🗂️ Folder Structure

```
pirateclick/
├── backend/
│   ├── src/
│   │   ├── modules/
│   │   │   └── license/           ← NEW: entire SaaS module
│   │   │       ├── models/
│   │   │       │   ├── User.js
│   │   │       │   └── License.js
│   │   │       ├── repositories/
│   │   │       │   ├── userRepository.js
│   │   │       │   └── licenseRepository.js
│   │   │       ├── services/
│   │   │       │   ├── authService.js
│   │   │       │   ├── licenseService.js
│   │   │       │   └── notificationService.js
│   │   │       ├── controllers/
│   │   │       │   ├── authController.js
│   │   │       │   ├── licenseController.js
│   │   │       │   └── adminController.js
│   │   │       ├── middleware/
│   │   │       │   ├── authMiddleware.js
│   │   │       │   ├── adminMiddleware.js
│   │   │       │   └── rateLimiter.js
│   │   │       ├── routes/
│   │   │       │   └── index.js
│   │   │       └── index.js       ← mount() + injectWhatsApp()
│   │   ├── nlp/                   ← UNTOUCHED
│   │   ├── location/              ← UNTOUCHED
│   │   ├── drivers/               ← UNTOUCHED
│   │   ├── decision/              ← UNTOUCHED
│   │   ├── whatsapp/              ← UNTOUCHED
│   │   ├── queue/                 ← UNTOUCHED
│   │   ├── learning/              ← UNTOUCHED
│   │   ├── metrics/               ← UNTOUCHED
│   │   ├── db/                    ← UNTOUCHED (mongo + redis)
│   │   ├── utils/                 ← UNTOUCHED
│   │   └── server.js              ← UPDATED (2 lines added)
│   ├── scripts/
│   │   └── generateSecrets.js
│   ├── package.json               ← UPDATED (added bcryptjs, jsonwebtoken)
│   └── .env.example               ← UPDATED (added JWT + admin vars)
│
└── electron/
    ├── src/
    │   ├── renderer/
    │   │   ├── auth.html          ← NEW: Login/Register UI
    │   │   ├── index.html         ← UNTOUCHED
    │   │   ├── dashboard.js       ← UNTOUCHED
    │   │   └── styles.css         ← UNTOUCHED
    │   ├── main.js                ← UPDATED (boot sequence, license check)
    │   ├── preload.js             ← UPDATED (added pirateAPI namespace)
    │   ├── deviceFingerprint.js   ← NEW
    │   └── tokenStore.js          ← NEW (keytar + AES fallback)
    ├── build/
    └── package.json               ← UPDATED (added keytar)
```

---

## 🔌 API Endpoints Reference

### Auth  (`/api/auth`)

| Method | Endpoint           | Auth    | Body                              | Description            |
|--------|--------------------|---------|-----------------------------------|------------------------|
| POST   | `/register`        | none    | name, phone, email, password, device_id | Register new user |
| POST   | `/login`           | none    | email, password, device_id        | Login, returns JWT     |
| POST   | `/refresh`         | Bearer  | —                                 | Refresh JWT            |
| GET    | `/me`              | Bearer  | —                                 | Get own profile        |

### License  (`/api/license`)

| Method | Endpoint           | Auth    | Headers          | Description            |
|--------|--------------------|---------|------------------|------------------------|
| GET    | `/check`           | Bearer  | X-Device-Id      | Startup license check  |
| GET    | `/my`              | Bearer  | —                | List own licenses      |

### Admin  (`/api/admin`)  — `X-Admin-Key` header required

| Method | Endpoint                      | Body                            | Description              |
|--------|-------------------------------|---------------------------------|--------------------------|
| GET    | `/users`                      | —                               | List all users           |
| GET    | `/users/:id`                  | —                               | User + their licenses    |
| POST   | `/users/:id/approve`          | —                               | Approve pending user     |
| POST   | `/users/:id/ban`              | reason                          | Ban user                 |
| POST   | `/users/:id/reset-device`     | —                               | Clear device binding     |
| GET    | `/licenses`                   | —                               | List all licenses        |
| POST   | `/licenses/assign`            | user_id, plan, duration_days    | Assign/renew license     |
| PATCH  | `/licenses/:id/expiry`        | expiry_date                     | Update expiry date       |
| DELETE | `/licenses/:id`               | —                               | Deactivate license       |

---

## ⚙️ Step-by-Step Integration Guide

### Step 1 — Generate secrets

```bash
cd backend
node scripts/generateSecrets.js
```

Copy the output into your `.env`.

### Step 2 — Configure `.env`

```bash
cp .env.example .env
```

Fill in:
- `JWT_SECRET`       — from step 1
- `ADMIN_API_KEY`    — from step 1
- `MONGO_URI`        — your MongoDB connection string
- `ADMIN_WA_NUMBER`  — your WhatsApp number for notifications (e.g. `905321234567`)
- `REDIS_HOST`       — your Redis host

### Step 3 — Install backend dependencies

```bash
cd backend
npm install
```

### Step 4 — Start backend

```bash
npm start
# or for development:
npm run dev
```

### Step 5 — Test the license API

```bash
# Register a user
curl -X POST https://your-server.com/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Test User","phone":"905321234567","email":"test@test.com","password":"12345678"}'

# Approve user (admin)
curl -X POST https://your-server.com/api/admin/users/USER_ID/approve \
  -H "X-Admin-Key: YOUR_ADMIN_API_KEY"

# Assign license (admin)
curl -X POST https://your-server.com/api/admin/licenses/assign \
  -H "X-Admin-Key: YOUR_ADMIN_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"user_id":"USER_ID","plan":"pro","duration_days":30}'

# Login
curl -X POST https://your-server.com/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"12345678","device_id":"abc123"}'

# Check license
curl https://your-server.com/api/license/check \
  -H "Authorization: Bearer JWT_TOKEN" \
  -H "X-Device-Id: abc123"
```

### Step 6 — Configure Electron for production

In `electron/src/main.js` the API URL defaults to:
```
process.env.API_URL || 'https://api.pirateclick.com'
```

Set your real server URL in the Electron build environment:

```bash
# For development
cd electron
npm run start:dev
# This uses API_URL=http://localhost:3001

# For production build
API_URL=https://api.yourserver.com npm run build:win
```

Or set it permanently in `electron/src/main.js`:
```js
const BACKEND_URL = 'https://api.yourserver.com';
```

### Step 7 — Build the EXE

```bash
cd electron
npm install
npm run build:win
# Output: electron/dist/PirateClick-Setup-1.0.0.exe
```

---

## 💰 Plan Feature Matrix

| Feature              | BASIC | PRO  | PREMIUM |
|----------------------|-------|------|---------|
| Max drivers          | 5     | 20   | ∞       |
| Max messages/min     | 20    | 60   | 300     |
| Adaptive learning    | ❌    | ✅   | ✅      |
| Analytics            | ❌    | ✅   | ✅      |
| Priority dispatch    | ❌    | ❌   | ✅      |
| Multi-group          | ❌    | ✅   | ✅      |

Limits are enforced via `license.limits` returned in the `/api/license/check` response.
Your existing backend can read these limits from the JWT or cache and enforce `max_drivers`,
`max_msg_per_min`, etc. in the relevant workers.

---

## 🔒 Security Notes

- Passwords are hashed with **bcrypt** (12 rounds)
- JWTs are **HS256** signed, expire in 7 days, and include a `token_version` field — incrementing this invalidates all existing tokens for a user (ban, forced logout)
- JWT is stored in **OS Keychain** (Windows Credential Manager / macOS Keychain / libsecret) via `keytar`, with an AES-256-GCM encrypted file fallback
- Device binding uses a **SHA-256 hardware fingerprint** — mismatched devices are blocked at login
- Admin API is **REST-only**, key-protected, no frontend surface
- Auth endpoints are **rate-limited**: 10 attempts per 15 minutes per IP
- All responses strip the `password` field via Mongoose `select: false`

---

## 🚀 Deployment (Recommended: Railway / Render / VPS)

1. Push backend to your cloud provider
2. Set all `.env` variables in the cloud dashboard
3. Ensure MongoDB Atlas URI is set in `MONGO_URI`
4. Ensure Redis is available (Railway / Upstash)
5. Point Electron `API_URL` to your deployed backend URL
6. Build and distribute the EXE to customers
