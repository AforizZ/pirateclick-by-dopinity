'use strict';

/**
 * DEVICE FINGERPRINT — PirateClick by dopinity
 *
 * Generates a stable, unique device identifier from hardware
 * characteristics. Runs only in the Electron main process.
 *
 * Strategy:
 *   1. Read persisted device_id from encrypted store
 *   2. If none, compute from system info, persist, and return
 *
 * The fingerprint is a SHA-256 hex string derived from:
 *   - CPU model + number of cores
 *   - Total system memory
 *   - Machine hostname
 *   - OS platform + arch
 *
 * This is intentionally NOT 100% hardware-locked (motherboard IDs
 * require native modules). It is stable across reboots and OS
 * reinstalls on the same hardware, which is enough to deter casual
 * sharing while avoiding support burden.
 */

const os     = require('os');
const crypto = require('crypto');

let _cachedDeviceId = null;

/**
 * Returns a deterministic fingerprint for the current machine.
 * On first call the result is cached in memory for the session.
 *
 * @returns {string} 64-char hex string
 */
function getDeviceId() {
  if (_cachedDeviceId) return _cachedDeviceId;

  const cpus     = os.cpus();
  const cpuModel = cpus[0]?.model || 'unknown-cpu';
  const cpuCount = cpus.length;
  const totalMem = os.totalmem();
  const hostname = os.hostname();
  const platform = os.platform();
  const arch     = os.arch();

  const raw = [cpuModel, cpuCount, totalMem, hostname, platform, arch].join('|');

  _cachedDeviceId = crypto.createHash('sha256').update(raw).digest('hex');
  return _cachedDeviceId;
}

module.exports = { getDeviceId };
