'use strict';

/**
 * ELECTRON MAIN PROCESS — PirateClick by dopinity
 *
 * Boot sequence:
 *   1. Splash screen (2.5s)
 *   2. Check stored JWT → run license check
 *   3. If no token → Auth window (login / register)
 *   4. After login → license check → open dashboard
 *   5. If blocked → block screen + clear token
 */

const {
  app, BrowserWindow, ipcMain, Tray, Menu, shell, Notification,
} = require('electron');
const path  = require('path');
const axios = require('axios');
const fs    = require('fs');

const { getDeviceId }              = require('./deviceFingerprint');
const { saveToken, loadToken, clearToken } = require('./tokenStore');

// ─── CONFIG ──────────────────────────────────────────────────────────────────
// ✏️  PRODUCTION: change this to your deployed backend URL before building EXE
const BACKEND_URL = process.env.API_URL || 'https://api.pirateclick.com';

let mainWindow  = null;
let authWindow  = null;
let splashWin   = null;
let tray        = null;

// ─── SPLASH ──────────────────────────────────────────────────────────────────
function createSplash() {
  splashWin = new BrowserWindow({
    width:           360,
    height:          320,
    frame:           false,
    transparent:     true,
    resizable:       false,
    center:          true,
    skipTaskbar:     true,
    backgroundColor: '#06060e',
    webPreferences:  { nodeIntegration: false, contextIsolation: true },
  });
  splashWin.loadFile(path.join(__dirname, 'renderer/splash.html'));
  splashWin.setIgnoreMouseEvents(false);
}

function closeSplash() {
  if (splashWin && !splashWin.isDestroyed()) {
    splashWin.destroy();
    splashWin = null;
  }
}

// ─── AUTH WINDOW ─────────────────────────────────────────────────────────────
function createAuthWindow() {
  authWindow = new BrowserWindow({
    width:           440,
    height:          640,
    resizable:       false,
    center:          true,
    title:           'PirateClick — Giriş',
    backgroundColor: '#06060e',
    frame:           false,
    titleBarStyle:   'hidden',
    webPreferences: {
      preload:         path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration:  false,
    },
    show: false,
  });

  authWindow.loadFile(path.join(__dirname, 'renderer/auth.html'));
  authWindow.once('ready-to-show', () => {
    closeSplash();
    authWindow.show();
  });
}

// ─── DASHBOARD WINDOW ────────────────────────────────────────────────────────
function createMainWindow() {
  mainWindow = new BrowserWindow({
    width:           1300,
    height:          820,
    minWidth:        960,
    minHeight:       600,
    title:           'PirateClick by dopinity',
    backgroundColor: '#0f0f1a',
    titleBarStyle:   'hidden',
    webPreferences: {
      preload:         path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration:  false,
    },
    show: false,
  });

  mainWindow.loadFile(path.join(__dirname, 'renderer/index.html'));
  mainWindow.once('ready-to-show', () => {
    closeSplash();
    mainWindow.show();
  });

  mainWindow.on('close', (e) => {
    if (!app.isQuiting) { e.preventDefault(); mainWindow.hide(); }
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

// ─── BLOCK SCREEN ────────────────────────────────────────────────────────────
function createBlockWindow(message) {
  const win = new BrowserWindow({
    width: 460, height: 300,
    resizable: false, center: true,
    backgroundColor: '#0a0606',
    frame: false,
    webPreferences: { nodeIntegration: false, contextIsolation: true,
      preload: path.join(__dirname, 'preload.js') },
  });

  const safe = message.replace(/</g, '&lt;').replace(/>/g, '&gt;');
  win.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(`<!DOCTYPE html>
<html><head><meta charset="UTF-8"><style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Segoe UI',system-ui,sans-serif;background:#0a0606;color:#e2e8f0;
  display:flex;flex-direction:column;align-items:center;justify-content:center;
  height:100vh;text-align:center;padding:32px;gap:16px;user-select:none;}
.icon{font-size:52px;filter:drop-shadow(0 0 16px rgba(239,68,68,0.5));}
h2{font-size:18px;color:#ef4444;font-weight:700;}
p{font-size:13px;color:#94a3b8;line-height:1.6;max-width:340px;}
button{margin-top:8px;padding:10px 32px;border:none;border-radius:8px;
  background:#ef4444;color:#fff;font-size:14px;font-weight:600;cursor:pointer;}
button:hover{background:#dc2626;}
</style></head><body>
<div class="icon">🔒</div>
<h2>Abonelik Gerekli</h2>
<p>${safe}</p>
<button onclick="window.pirateAPI.exitApp()">Kapat</button>
</body></html>`));
}

// ─── LICENSE CHECK ────────────────────────────────────────────────────────────
async function runLicenseCheck(token) {
  try {
    const res = await axios.get(`${BACKEND_URL}/api/license/check`, {
      headers: { Authorization: `Bearer ${token}`, 'X-Device-Id': getDeviceId() },
      timeout: 10000,
    });
    return res.data;
  } catch (err) {
    const data = err.response?.data;
    if (data && data.allowed === false) return data;
    // Network unreachable — allow app to open with warning
    return { allowed: true, offline: true };
  }
}

// ─── TRAY ────────────────────────────────────────────────────────────────────
function createTray() {
  try {
    const ico = path.join(__dirname, '../build/icon.png');
    if (!fs.existsSync(ico)) return;
    tray = new Tray(ico);
    tray.setToolTip('PirateClick by dopinity');
    tray.setContextMenu(Menu.buildFromTemplate([
      { label: 'PirateClick', enabled: false },
      { type: 'separator' },
      { label: 'Aç',   click: () => mainWindow?.show() },
      { type: 'separator' },
      { label: 'Çıkış', click: () => { app.isQuiting = true; app.quit(); } },
    ]));
    tray.on('double-click', () => mainWindow?.show());
  } catch (_) {}
}

// ─── BOOT ────────────────────────────────────────────────────────────────────
async function boot() {
  createSplash();

  await new Promise(r => setTimeout(r, 2600)); // Let splash animate

  const token = await loadToken();

  if (!token) {
    createAuthWindow();
    return;
  }

  const result = await runLicenseCheck(token);

  if (!result.allowed) {
    closeSplash();
    createBlockWindow(result.message || 'Aboneliğiniz aktif değil. Destek ile iletişime geçin.');
    await clearToken();
    return;
  }

  createMainWindow();
  createTray();
}

// ─── IPC ─────────────────────────────────────────────────────────────────────

// Called by auth screen after successful login
ipcMain.handle('auth-success', async (_, { token }) => {
  await saveToken(token);
  const result = await runLicenseCheck(token);

  if (!result.allowed) {
    await clearToken();
    if (authWindow) {
      // Show block inline — don't open new window
      return { ok: false, blocked: true, message: result.message };
    }
  }

  // Open dashboard
  if (authWindow && !authWindow.isDestroyed()) { authWindow.destroy(); authWindow = null; }
  createMainWindow();
  createTray();
  return { ok: true, license: result };
});

// Generic proxied API call
ipcMain.handle('api-request', async (_, { method, path: apiPath, body, auth }) => {
  try {
    const token = auth || await loadToken();
    const headers = token ? { Authorization: `Bearer ${token}` } : {};
    headers['X-Device-Id'] = getDeviceId();

    const res = await axios({ method: method || 'GET', url: BACKEND_URL + apiPath,
      data: body, headers, timeout: 12000 });
    return { ok: true, data: res.data };
  } catch (err) {
    return { ok: false, error: err.response?.data || err.message };
  }
});

ipcMain.handle('get-backend-url', () => BACKEND_URL);
ipcMain.handle('get-device-id',   () => getDeviceId());
ipcMain.handle('logout',          async () => {
  await clearToken();
  if (mainWindow && !mainWindow.isDestroyed()) { mainWindow.destroy(); mainWindow = null; }
  createAuthWindow();
});
ipcMain.handle('exit-app',        () => { app.isQuiting = true; app.quit(); });

ipcMain.on('show-notification', (_, { title, body }) => {
  new Notification({ title, body }).show();
});

// ─── LIFECYCLE ────────────────────────────────────────────────────────────────
app.whenReady().then(boot);

app.on('before-quit', () => { app.isQuiting = true; });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
