'use strict';

const { contextBridge, ipcRenderer } = require('electron');

/**
 * PRELOAD — PirateClick by dopinity
 *
 * Exposes two namespaces to the renderer:
 *   window.dispatch   — existing dashboard API (untouched)
 *   window.pirateAPI  — new SaaS auth + license API
 */

// ── Existing dashboard API (untouched) ────────────────────────────────────────
contextBridge.exposeInMainWorld('dispatch', {
  api:          (method, path, body) => ipcRenderer.invoke('api-request', { method, path, body }),
  getBackendUrl: () => ipcRenderer.invoke('get-backend-url'),
  notify:       (title, body) => ipcRenderer.send('show-notification', { title, body }),
  openLogs:     () => ipcRenderer.invoke('open-logs-dir'),
  onWsConnect:  (cb) => ipcRenderer.on('ws-connect', (_, url) => cb(url)),
  onNavigate:   (cb) => ipcRenderer.on('navigate', (_, page) => cb(page)),
});

// ── New SaaS / Auth API ───────────────────────────────────────────────────────
contextBridge.exposeInMainWorld('pirateAPI', {
  /**
   * Called after login succeeds in the auth screen.
   * Main process will save token + run license check.
   */
  authSuccess: (token) => ipcRenderer.invoke('auth-success', { token }),

  /**
   * Raw API call — used by auth screen (no stored token yet).
   * @param {string} method
   * @param {string} path
   * @param {object} body
   * @param {string?} auth  - JWT to use (overrides stored token)
   */
  api: (method, path, body, auth) =>
    ipcRenderer.invoke('api-request', { method, path, body, auth }),

  /** Get device fingerprint */
  getDeviceId: () => ipcRenderer.invoke('get-device-id'),

  /** Log the user out and return to auth screen */
  logout: () => ipcRenderer.invoke('logout'),

  /** Quit the app (used by block screen) */
  exitApp: () => ipcRenderer.invoke('exit-app'),
});
