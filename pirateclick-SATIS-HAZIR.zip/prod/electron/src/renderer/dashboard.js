'use strict';

/* ─── State ─────────────────────────────────────────────────── */
let ws = null;
let currentPage = 'dashboard';
let settingsData = {};

/* ─── Navigation ─────────────────────────────────────────────── */
document.querySelectorAll('.nav-item').forEach((item) => {
  item.addEventListener('click', () => {
    navigateTo(item.dataset.page);
  });
});

function navigateTo(page) {
  document.querySelectorAll('.nav-item').forEach((i) => i.classList.remove('active'));
  document.querySelectorAll('.page').forEach((p) => p.classList.remove('active'));

  const navItem = document.querySelector(`[data-page="${page}"]`);
  const pageEl  = document.getElementById(`page-${page}`);

  if (navItem) navItem.classList.add('active');
  if (pageEl)  pageEl.classList.add('active');

  currentPage = page;

  if (page === 'drivers')  refreshDrivers();
  if (page === 'jobs')     refreshJobs();
  if (page === 'settings') loadSettings();
  if (page === 'learning') loadLearning();
}

// Tray navigation events
if (window.dispatch) {
  window.dispatch.onNavigate((page) => navigateTo(page));
}

/* ─── WebSocket ─────────────────────────────────────────────── */
if (window.dispatch) {
  window.dispatch.onWsConnect((wsUrl) => {
    connectWS(wsUrl);
  });
}

function connectWS(url) {
  if (ws) ws.close();

  ws = new WebSocket(url);

  ws.onopen = () => {
    updateConnectionStatus('connected');
    log('WebSocket bağlandı', 'info');
  };

  ws.onmessage = (event) => {
    try {
      const { event: evtName, data } = JSON.parse(event.data);
      handleWsEvent(evtName, data);
    } catch (e) { /* ignore parse errors */ }
  };

  ws.onclose = () => {
    updateConnectionStatus('disconnected');
    setTimeout(() => connectWS(url), 3000);
  };

  ws.onerror = () => {
    updateConnectionStatus('disconnected');
  };
}

function handleWsEvent(event, data) {
  switch (event) {
    case 'qr':
      showQR(data.qr);
      updateConnectionStatus('qr');
      break;
    case 'status':
      updateConnectionStatus(data.status);
      if (data.status === 'connected') {
        document.getElementById('qr-section')?.classList.add('hidden');
        refreshMetrics();
      }
      break;
    case 'message':
      log(`📨 ${(data.groupId || '').slice(0, 20)} — ${(data.text || '').slice(0, 60)}`, 'info');
      refreshMetrics();
      break;
  }
}

/* ─── Connection Status ───────────────────────────────────────── */
function updateConnectionStatus(status) {
  const badge = document.getElementById('conn-status');
  if (!badge) return;

  const labels = {
    connected:    '⚡ Bağlı',
    disconnected: '❌ Bağlı Değil',
    qr_pending:   '📱 QR Bekliyor',
    qr:           '📱 QR Bekliyor',
  };

  badge.textContent = labels[status] || status;
  badge.className = 'status-badge ' +
    (status === 'connected' ? '' : (status === 'qr' || status === 'qr_pending') ? 'qr' : 'disconnected');
}

/* ─── QR Code ───────────────────────────────────────────────── */
function showQR(qrData) {
  const section = document.getElementById('qr-section');
  const display = document.getElementById('qr-display');
  if (!section || !display) return;

  section.classList.remove('hidden');
  // Display QR as text (Electron can render this, or integrate qrcode.js)
  display.innerHTML = `<pre style="font-size:6px;line-height:6px;letter-spacing:2px;color:white;background:#000;padding:12px;display:inline-block;border-radius:8px;">${escHtml(qrData)}</pre>
  <p style="margin-top:8px;font-size:0.8rem;color:var(--text-muted)">QR kodu WhatsApp uygulamasından okutun</p>`;
}

/* ─── Metrics ───────────────────────────────────────────────── */
async function refreshMetrics() {
  if (!window.dispatch) return;
  const res = await window.dispatch.api('GET', '/api/metrics');
  if (!res.ok) return;

  const m = res.data;

  setText('m-accuracy',    m.nlpAccuracy != null ? (m.nlpAccuracy * 100).toFixed(1) + '%' : '—');
  setText('m-p95',         m.latency?.p95 != null ? m.latency.p95 + 'ms' : '—');
  setText('m-success',     m.successRate != null ? (m.successRate * 100).toFixed(1) + '%' : '—');
  setText('m-total-jobs',  m.jobs?.total ?? '—');
  setText('m-accept-rate', m.acceptanceRate != null ? (m.acceptanceRate * 100).toFixed(1) + '%' : '—');

  const drvRes = await window.dispatch.api('GET', '/api/drivers');
  if (drvRes.ok) setText('m-drivers', drvRes.data.count ?? '—');
}

/* ─── Live Log ──────────────────────────────────────────────── */
const MAX_LOG_ENTRIES = 200;

function log(message, type) {
  type = type || 'info';
  const feed = document.getElementById('live-log');
  if (!feed) return;

  const entry = document.createElement('div');
  entry.className = `log-entry ${type}`;
  entry.innerHTML = `<span class="ts">${new Date().toLocaleTimeString('tr-TR')}</span>${escHtml(message)}`;

  feed.appendChild(entry);
  feed.scrollTop = feed.scrollHeight;

  while (feed.children.length > MAX_LOG_ENTRIES) {
    feed.removeChild(feed.firstChild);
  }
}

/* ─── Drivers Page ──────────────────────────────────────────── */
async function refreshDrivers() {
  if (!window.dispatch) return;
  const res = await window.dispatch.api('GET', '/api/drivers');
  if (!res.ok) return;

  const tbody = document.getElementById('drivers-tbody');
  if (!tbody) return;
  tbody.innerHTML = '';

  if (res.data.drivers.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:var(--text-muted)">Aktif sürücü yok</td></tr>';
    return;
  }

  for (const d of res.data.drivers) {
    const row = document.createElement('tr');
    const statusBadge = d.status === 'available'
      ? '<span class="badge badge-success">Müsait</span>'
      : '<span class="badge badge-warning">Meşgul</span>';
    const confidence = d.confidence != null ? (d.confidence * 100).toFixed(0) + '%' : '—';
    const lastSeen  = d.lastseen ? new Date(d.lastseen).toLocaleTimeString('tr-TR') : '—';

    row.innerHTML = `
      <td>${escHtml((d.driverid || '').slice(0, 20))}</td>
      <td>${escHtml(d.location?.primary || '—')}</td>
      <td>${statusBadge}</td>
      <td>${confidence}</td>
      <td>${lastSeen}</td>
    `;
    tbody.appendChild(row);
  }
}

/* ─── Jobs Page ─────────────────────────────────────────────── */
async function refreshJobs() {
  if (!window.dispatch) return;
  const res = await window.dispatch.api('GET', '/api/jobs');
  if (!res.ok) return;

  const tbody = document.getElementById('jobs-tbody');
  if (!tbody) return;
  tbody.innerHTML = '';

  for (const j of res.data.jobs) {
    const row = document.createElement('tr');
    const sc = { assigned: 'success', failed: 'danger', pending: 'warning', claimed: 'info', completed: 'success', rejected: 'danger' };
    const statusClass = sc[j.status] || 'info';

    row.innerHTML = `
      <td style="font-family:monospace;font-size:0.75rem">${escHtml((j.messageId || '').slice(0, 14))}...</td>
      <td>${escHtml(j.entities?.pickup?.display || '—')}</td>
      <td>${escHtml(j.entities?.destination?.display || '—')}</td>
      <td>${j.entities?.price?.amount != null ? j.entities.price.amount + ' ₺' : '—'}</td>
      <td><span class="badge badge-${statusClass}">${escHtml(j.status)}</span></td>
      <td>${escHtml((j.assignedDriver || '').slice(0, 15) || '—')}</td>
      <td>${j.confidence != null ? (j.confidence * 100).toFixed(0) + '%' : '—'}</td>
      <td>${j.createdAt ? new Date(j.createdAt).toLocaleString('tr-TR') : '—'}</td>
    `;
    tbody.appendChild(row);
  }
}

/* ─── Settings Page ─────────────────────────────────────────── */
const ALL_DISTRICTS = [
  'esenyurt','avcilar','beylikduzu','bakirkoy','bahcelievler','bagcilar',
  'gungoren','zeytinburnu','fatih','beyoglu','besiktas','sisli',
  'kagithane','sariyer','eyup','gaziosmanpasa','sultangazi','esenler',
  'bayrampasa','kucukcekmece','buyukcekmece','silivri','catalca','arnavutkoy',
  'kadikoy','uskudar','beykoz','atasehir','umraniye','maltepe','kartal',
  'pendik','tuzla','sancaktepe','sultanbeyli','cekmekoy',
  'havalimani','sabiha',
];

async function loadSettings() {
  if (!window.dispatch) return;
  const res = await window.dispatch.api('GET', '/api/settings');
  if (res.ok) {
    settingsData = {};
    for (const s of res.data.settings) {
      settingsData[s.districtKey] = s.minPrice;
    }
  }
  renderSettingsGrid('');
}

function renderSettingsGrid(filter) {
  const grid = document.getElementById('district-settings-grid');
  if (!grid) return;
  grid.innerHTML = '';

  const filtered = ALL_DISTRICTS.filter((d) =>
    d.toLowerCase().includes(filter.toLowerCase())
  );

  for (const district of filtered) {
    const item = document.createElement('div');
    item.className = 'setting-item';
    item.innerHTML = `
      <label>${capitalize(district)}</label>
      <input type="number" min="0" max="9999" step="10"
             value="${settingsData[district] || 0}"
             data-district="${district}"
             class="setting-price-input">
      <span style="font-size:0.8rem;color:var(--text-muted)">₺</span>
    `;
    grid.appendChild(item);
  }
}

const settingsSearch = document.getElementById('settings-search');
if (settingsSearch) {
  settingsSearch.addEventListener('input', (e) => {
    renderSettingsGrid(e.target.value);
  });
}

async function saveAllSettings() {
  if (!window.dispatch) return;
  const inputs = document.querySelectorAll('.setting-price-input');
  const promises = [];

  for (const input of inputs) {
    const district = input.dataset.district;
    const price    = parseInt(input.value, 10) || 0;
    promises.push(
      window.dispatch.api('POST', '/api/settings', { district, minPrice: price, active: true })
    );
  }

  await Promise.all(promises);
  window.dispatch.notify('Ayarlar', 'Tüm ayarlar kaydedildi ✓');
  log('Ayarlar kaydedildi', 'info');
}

/* ─── Learning Page ─────────────────────────────────────────── */
async function loadLearning() {
  if (!window.dispatch) return;
  const res = await window.dispatch.api('GET', '/api/learning');
  if (!res.ok) return;

  const list = document.getElementById('learning-list');
  if (!list) return;
  list.innerHTML = '';

  if (res.data.pending.length === 0) {
    list.innerHTML = '<p style="color:var(--text-muted)">Bekleyen öneri yok.</p>';
    return;
  }

  for (const item of res.data.pending) {
    const el = document.createElement('div');
    el.className = 'learning-item';
    el.innerHTML = `
      <span class="learning-token">${escHtml(item.token)}</span>
      <span class="learning-suggestion">→ ${escHtml(item.suggestedAlias || '?')}</span>
      <span class="learning-count">${item.occurrences}x</span>
      ${item.suggestedAlias
        ? `<button class="btn-primary" style="margin:0;padding:5px 12px;font-size:0.8rem"
             onclick="applyAlias('${escAttr(item.token)}','${escAttr(item.suggestedAlias)}')">✓ Onayla</button>`
        : '<span style="color:var(--text-muted);font-size:0.8rem">Manuel inceleme gerek</span>'
      }
    `;
    list.appendChild(el);
  }
}

async function applyAlias(token, correction) {
  if (!window.dispatch) return;
  const res = await window.dispatch.api('POST', '/api/learning/apply', { token, correction, type: 'location' });
  if (res.ok) {
    log(`Alias uygulandı: ${token} → ${correction}`, 'info');
    loadLearning();
  }
}

async function runLearningCycle() {
  if (!window.dispatch) return;
  log('Öğrenme döngüsü başlatıldı...', 'info');
  const res = await window.dispatch.api('POST', '/api/learning/run-cycle', {});
  if (res.ok) {
    log(`Öğrenme döngüsü tamamlandı. ${res.data.suggestions?.length || 0} öneri üretildi.`, 'info');
    loadLearning();
  }
}

/* ─── Support Form ──────────────────────────────────────────── */
const supportForm = document.getElementById('support-form');
if (supportForm) {
  supportForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!window.dispatch) return;

    const name    = document.getElementById('sup-name')?.value;
    const email   = document.getElementById('sup-email')?.value;
    const subject = document.getElementById('sup-subject')?.value;
    const message = document.getElementById('sup-message')?.value;
    const status  = document.getElementById('support-status');

    const res = await window.dispatch.api('POST', '/api/support', { name, email, subject, message });

    if (status) {
      status.textContent = res.ok
        ? '✅ Mesajınız gönderildi, en kısa sürede yanıt vereceğiz.'
        : '❌ Gönderilemedi. Lütfen tekrar deneyin.';
      status.style.color = res.ok ? 'var(--success)' : 'var(--danger)';
    }
  });
}

/* ─── Helpers ───────────────────────────────────────────────── */
function setText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

function escHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function escAttr(str) {
  return String(str || '')
    .replace(/'/g, "\\'").replace(/"/g, '\\"');
}

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

/* ─── Init ──────────────────────────────────────────────────── */
(async function init() {
  await refreshMetrics();

  // Auto-refresh metrics every 10s
  setInterval(refreshMetrics, 10000);

  // Check QR on startup
  if (window.dispatch) {
    const statusRes = await window.dispatch.api('GET', '/api/status');
    if (statusRes.ok) {
      updateConnectionStatus(statusRes.data.status);

      if (statusRes.data.status !== 'connected') {
        const qrInterval = setInterval(async () => {
          const qrRes = await window.dispatch.api('GET', '/api/qr');
          if (qrRes.ok && qrRes.data.qr) {
            showQR(qrRes.data.qr);
            clearInterval(qrInterval);
          }
        }, 2000);
      }
    }
  }

  log('Dispatch AI başlatıldı', 'info');
})();
