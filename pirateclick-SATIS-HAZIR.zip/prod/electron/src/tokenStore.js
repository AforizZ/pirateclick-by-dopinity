'use strict';

/**
 * SECURE TOKEN STORE — PirateClick by dopinity
 *
 * Saves JWT in the OS credential manager via keytar.
 * Falls back to AES-256-GCM encrypted file in userData.
 *
 * ⚠️  Plain localStorage is NEVER used.
 */

const path    = require('path');
const fs      = require('fs');
const crypto  = require('crypto');
const os      = require('os');
const { app } = require('electron');

const SERVICE  = 'PirateClick';
const ACCOUNT  = 'user-auth-token';

function getFallbackPath() {
  return path.join(app.getPath('userData'), '.token.enc');
}

function deriveKey() {
  return crypto.scryptSync(
    app.getName() + os.hostname(),
    'pirateclick-salt-v1',
    32
  );
}

// ─── keytar (primary) ─────────────────────────────────────────────────────────
let keytar = null;
try { keytar = require('keytar'); } catch (_) {}

// ─── Public API ───────────────────────────────────────────────────────────────

async function saveToken(token) {
  if (keytar) {
    try { await keytar.setPassword(SERVICE, ACCOUNT, token); return; }
    catch (e) { console.warn('[TokenStore] keytar failed, using file fallback:', e.message); }
  }
  saveFallback(token);
}

async function loadToken() {
  if (keytar) {
    try {
      const token = await keytar.getPassword(SERVICE, ACCOUNT);
      if (token) return token;
    } catch (e) { console.warn('[TokenStore] keytar read failed:', e.message); }
  }
  return loadFallback();
}

async function clearToken() {
  if (keytar) {
    try { await keytar.deletePassword(SERVICE, ACCOUNT); } catch (_) {}
  }
  const p = getFallbackPath();
  if (fs.existsSync(p)) fs.unlinkSync(p);
}

// ─── AES-256-GCM fallback ─────────────────────────────────────────────────────

function saveFallback(token) {
  const key    = deriveKey();
  const iv     = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const enc    = Buffer.concat([cipher.update(token, 'utf8'), cipher.final()]);
  const tag    = cipher.getAuthTag();

  const payload = JSON.stringify({
    iv:  iv.toString('hex'),
    tag: tag.toString('hex'),
    enc: enc.toString('hex'),
  });

  fs.writeFileSync(getFallbackPath(), payload, { mode: 0o600 });
}

function loadFallback() {
  const p = getFallbackPath();
  if (!fs.existsSync(p)) return null;
  try {
    const { iv, tag, enc } = JSON.parse(fs.readFileSync(p, 'utf8'));
    const key      = deriveKey();
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(iv, 'hex'));
    decipher.setAuthTag(Buffer.from(tag, 'hex'));
    return decipher.update(Buffer.from(enc, 'hex')) + decipher.final('utf8');
  } catch (e) {
    console.warn('[TokenStore] Fallback decrypt failed — clearing:', e.message);
    fs.unlinkSync(p);
    return null;
  }
}

module.exports = { saveToken, loadToken, clearToken };
