#!/usr/bin/env node
'use strict';

/**
 * BUILD SCRIPT
 *
 * 1. Installs backend dependencies
 * 2. Installs Electron app dependencies
 * 3. Runs electron-builder
 * 4. Outputs EXE to electron/dist/
 */

const { execSync } = require('child_process');
const path         = require('path');
const fs           = require('fs');

const ROOT     = path.join(__dirname, '..');
const BACKEND  = path.join(ROOT, 'backend');
const ELECTRON = path.join(ROOT, 'electron');

function run(cmd, cwd) {
  console.log(`\n▶ ${cmd}\n  (in ${cwd})`);
  execSync(cmd, { cwd, stdio: 'inherit' });
}

function step(label) {
  console.log(`\n${'─'.repeat(60)}\n  ${label}\n${'─'.repeat(60)}`);
}

// ── Step 1: Backend deps ──────────────────────────────────────
step('Installing backend dependencies');
run('npm install --omit=dev', BACKEND);

// ── Step 2: Copy .env if not present ─────────────────────────
const envDest = path.join(BACKEND, '.env');
const envSrc  = path.join(BACKEND, '.env.example');
if (!fs.existsSync(envDest) && fs.existsSync(envSrc)) {
  fs.copyFileSync(envSrc, envDest);
  console.log('Copied .env.example → .env (please edit before distribution)');
}

// ── Step 3: Electron deps ─────────────────────────────────────
step('Installing Electron dependencies');
run('npm install', ELECTRON);

// ── Step 4: Build Electron app ────────────────────────────────
step('Building Electron EXE');
const platform = process.argv[2] || 'win';
run(`npm run build:${platform}`, ELECTRON);

step('✅ Build complete');
console.log(`Output: ${path.join(ELECTRON, 'dist')}`);
