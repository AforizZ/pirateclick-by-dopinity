'use strict';

/**
 * SHARED CONSTANTS
 *
 * Values used by both backend and Electron app.
 */

const INTENTS = {
  DRIVER_AVAILABLE:       'DRIVER_AVAILABLE',
  JOB_POST:               'JOB_POST',
  DRIVER_RESPONSE_ACCEPT: 'DRIVER_RESPONSE_ACCEPT',
  DRIVER_RESPONSE_REJECT: 'DRIVER_RESPONSE_REJECT',
  UNKNOWN:                'UNKNOWN',
};

const DRIVER_STATUS = {
  AVAILABLE: 'available',
  BUSY:      'busy',
  OFFLINE:   'offline',
};

const JOB_STATUS = {
  PENDING:   'pending',
  CLAIMED:   'claimed',
  ASSIGNED:  'assigned',
  COMPLETED: 'completed',
  FAILED:    'failed',
  REJECTED:  'rejected',
};

const ZONES = {
  EUROPE: 'europe',
  ASIA:   'asia',
};

const ALL_DISTRICTS = [
  'esenyurt', 'avcilar', 'beylikduzu', 'bakirkoy', 'bahcelievler', 'bagcilar',
  'gungoren', 'zeytinburnu', 'fatih', 'beyoglu', 'besiktas', 'sisli',
  'kagithane', 'sariyer', 'eyup', 'gaziosmanpasa', 'sultangazi', 'esenler',
  'bayrampasa', 'kucukcekmece', 'buyukcekmece', 'silivri', 'catalca', 'arnavutkoy',
  'kadikoy', 'uskudar', 'beykoz', 'atasehir', 'umraniye', 'maltepe', 'kartal',
  'pendik', 'tuzla', 'sancaktepe', 'sultanbeyli', 'cekmekoy',
  'havalimani', 'sabiha',
];

module.exports = {
  INTENTS,
  DRIVER_STATUS,
  JOB_STATUS,
  ZONES,
  ALL_DISTRICTS,
};
